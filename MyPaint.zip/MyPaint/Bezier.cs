﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPaint
{

   public class Bezier: HCN
    {
        
        public List<Point> points = new List<Point>();
        internal DashStyle dash;
        

        public override void Draw(Graphics graphics)
        {          
            Pen.DashStyle = dash;
           graphics.DrawCurve(Pen, points.ToArray());
           
        }
    }
    
}
