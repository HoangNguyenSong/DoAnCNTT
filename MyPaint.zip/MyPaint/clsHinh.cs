﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Drawing;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyPaint
{
    public abstract class clsHinh
    {
        public Point P1, P2;
        public Pen Pen;
        public Brush Brush;
        public bool CoToMau;
       
        internal object currShapeMode;
      
        protected Region region;
        // Tạo điểm điều khiển
        protected virtual Point GetHandlePoint(int handleNumber)
        {
            return new Point(0, 0);
        }

        
        public abstract void Draw(Graphics graphics);
    }
}
