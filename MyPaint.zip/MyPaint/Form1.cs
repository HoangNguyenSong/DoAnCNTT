﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;
using System.Drawing.Drawing2D;

namespace MyPaint
{
    public enum shapeMode
    {
        DoanThang,
        HinhTron,
        HinhVuong,
        HinhEllipse,
        HinhChuNhat,
        HinhDaGiac,
        DuongCongBezier,

    }
    public partial class Paint : Form
    {
        List<clsHinh> Hinh = new List<clsHinh>();
        bool isDown;
        Point diemchon;
        int currPenSize;
        shapeMode currShapMode;
        bool DuongThang;
        bool HCN;
        bool HV;
        bool HT;
        bool HELLIPSE;
        bool DaGiac;
        bool DuongCong;
        Bitmap bitmap;
        private DashStyle currDash;

        public Paint()
        {
            InitializeComponent();
            InitComboBoxSize();        
            // Giảm rung cho paint
            typeof(Panel).InvokeMember("DoubleBuffered", BindingFlags.SetProperty
             | BindingFlags.Instance | BindingFlags.NonPublic, null,
             main, new object[] { true });
            bitmap = new Bitmap(main.Height, main.Width);
        }

        // Màu
        private void btnMau_Click(object sender, EventArgs e)
        {
            ColorDialog color = new ColorDialog();
            if (color.ShowDialog() == DialogResult.OK)
            {
                btnMau.BackColor = color.Color;
            }
        }

        // Size
        private void InitComboBoxSize()
        {
            for (int i = 1; i <= 20; i++)
            {
                cmbSize.Items.Add(i);
            }
            cmbSize.SelectedIndex = 0;
        }

        // Thay đổi giá trị bút vẽ
        private void cmbSize_SelectedIndexChanged(object sender, EventArgs e)
        {
            currPenSize = int.Parse(cmbSize.Text);
        }
        //private int MoveHinh()
        //{
        //    int min = 1000;
        //    int min2 = 1000;
        //    int vtmin = -1;
        //    for (int i = 0; i < _Hinh.Count; i++)
        //    {
        //        if (_Hinh[i].currShapeMode != shapeMode.)
        //        {
        //            if (_Hinh[i].P1.X <= diemchon.X && _Hinh[i].P1.Y <= diemchon.Y
        //            && _Hinh[i].P2.X >= diemchon.X && _Hinh[i].P2.Y >= diemchon.Y)
        //            {
        //                if (min > (diemchon.Y - _Hinh[i].P1.Y))
        //                {
        //                    min = diemchon.Y - _Hinh[i].P1.Y;
        //                    vtmin = i;
        //                }
        //            }
        //            else if (_Hinh[i].P2.X >= diemchon.X && _Hinh[i].P2.Y <= diemchon.Y
        //                && _Hinh[i].P1.X <= diemchon.X && _Hinh[i].P1.Y >= diemchon.Y)
        //            {
        //                if (min2 > (diemchon.Y - _Hinh[i].P2.Y) && min2 <= min)
        //                {
        //                    min2 = diemchon.Y - _Hinh[i].P2.Y;
        //                    vtmin = i;
        //                }
        //            }
        //        }
        //        else
        //        {
        //            if (_Hinh[i].P2.Y <= diemchon.Y && _Hinh[i].P1.Y >= diemchon.Y)
        //            {
        //                if (min > (diemchon.Y - _Hinh[i].P1.Y))
        //                {
        //                    min = diemchon.Y - _Hinh[i].P1.Y;
        //                    vtmin = i;
        //                }
        //            }
        //            if (_Hinh[i].P2.Y >= diemchon.X && _Hinh[i].P1.Y <= diemchon.Y)
        //            {
        //                if (min2 > (diemchon.Y - _Hinh[i].P2.Y) && min2 <= min)
        //                {
        //                    min2 = diemchon.Y - _Hinh[i].P2.Y;
        //                    vtmin = i;
        //                }
        //            }
        //        }
        //    }
        //    min = 1000;
        //    min2 = 1000;
        //    return vtmin;
        //}
        private void main_Paint(object sender, PaintEventArgs e)
        {
           // Làm cho bút vẽ mịn hơn
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            for (int i = 0; i < Hinh.Count; i++)
            {
                Hinh[i].Draw(e.Graphics);
            }
        }

        private void main_MouseDown(object sender, MouseEventArgs e)
        {
            this.isDown = true;

            //Vẽ đường thẳng
            if(currShapMode == shapeMode.DoanThang)
            {
                if(DuongThang == false)
                {
                    DuongThang DT = new DuongThang();
                    DT.Pen = new Pen(btnMau.BackColor, (float)currPenSize);
                    DT.dash = currDash;
                    DT.Points.Add(e.Location);
                    DT.Points.Add(new Point());
                    DuongThang = true;
                    Hinh.Add(DT);
                   
                }
                else
                {
                    DuongThang duongThang = (DuongThang)Hinh[Hinh.Count - 1];
                    duongThang.Points[duongThang.Points.Count - 1] = e.Location;
                    duongThang.Points.Add(new Point());
                    DuongThang = false;
                    main.Refresh();
                }
            }

           //Vẽ hình chữ nhật
           if(currShapMode ==shapeMode.HinhChuNhat)
            {
                if(HCN == false)
                {
                    HCN hCN = new HCN();
                    hCN.Pen = new Pen(btnMau.BackColor, (float)currPenSize);
                    hCN.Brush = new SolidBrush(btnMau.BackColor);
                    hCN.dash = currDash;
                    if (radioBtnToMau.Checked == true)
                    {
                        hCN.CoToMau = true;
                    }

                    hCN.Points.Add(e.Location);
                    hCN.Points.Add(new Point());
                    HCN = true;
                    Hinh.Add(hCN);

                }
                else
                {
                    HCN _hCN = (HCN)Hinh[Hinh.Count - 1];
                    _hCN.Points[_hCN.Points.Count - 1] = e.Location;
                    _hCN.Points.Add(new Point());
                    HCN = false;
                    main.Refresh();
                }
           }

           //Vẽ hình vuông
           if(currShapMode == shapeMode.HinhVuong)
            {
                if (HV  == false)
                {
                    HV hV = new HV();
                    hV.Pen = new Pen(btnMau.BackColor, (float)currPenSize);
                    hV.Brush = new SolidBrush(btnMau.BackColor);
                    hV.dash = currDash;
                    if (radioBtnToMau.Checked == true)
                    {
                        hV.CoToMau = true;
                    }

                    hV.Points.Add(e.Location);
                    hV.Points.Add(new Point());
                    HV = true;
                    Hinh.Add(hV);

                }
                else
                {
                    HV hV = (HV)Hinh[Hinh.Count - 1];
                    hV.Points[hV.Points.Count - 1] = e.Location;
                    hV.Points.Add(new Point());
                    HV = false;
                    main.Refresh();
                }
            }

           //Vẽ hình tròn
           if(currShapMode == shapeMode.HinhTron)
            {
                if (HT == false)
                {
                    HT hT = new HT();
                    hT.Pen = new Pen(btnMau.BackColor, (float)currPenSize);
                    hT.Brush = new SolidBrush(btnMau.BackColor);
                    hT.dash = currDash;
                    if (radioBtnToMau.Checked == true)
                    {
                        hT.CoToMau = true;
                    }

                    hT.Points.Add(e.Location);
                    hT.Points.Add(new Point());
                    HT = true;
                    Hinh.Add(hT);

                }
                else
                {
                    HT hT = (HT)Hinh[Hinh.Count - 1];
                    hT.Points[hT.Points.Count - 1] = e.Location;
                    hT.Points.Add(new Point());
                    HT = false;
                    main.Refresh();
                }
            }

           //Vẽ hình ellipse
           if(currShapMode == shapeMode.HinhEllipse)
            {
                if (HELLIPSE == false)
                {
                    Ellipse hEllipse = new Ellipse();
                    hEllipse.Pen = new Pen(btnMau.BackColor, (float)currPenSize);
                    hEllipse.Brush = new SolidBrush(btnMau.BackColor);
                    hEllipse.dash = currDash;
                    if (radioBtnToMau.Checked == true)
                    {
                        hEllipse.CoToMau = true;
                    }

                    hEllipse.Points.Add(e.Location);
                    hEllipse.Points.Add(new Point());
                    HELLIPSE = true;
                    Hinh.Add(hEllipse);

                }
                else
                {
                    Ellipse hEllipse = (Ellipse)Hinh[Hinh.Count - 1];
                    hEllipse.Points[hEllipse.Points.Count - 1] = e.Location;
                    hEllipse.Points.Add(new Point());
                    HELLIPSE = false;
                    main.Refresh();
                }
            }

           // Vẽ đa giác
            if (currShapMode == shapeMode.HinhDaGiac)
            {
                if (DaGiac == false)
                {
                    DaGiac daGiac = new DaGiac();
                    daGiac.Pen = new Pen(btnMau.BackColor, (float)currPenSize);
                    daGiac.Brush = new SolidBrush(btnMau.BackColor);
                    daGiac.dash = currDash;
                    if (radioBtnToMau.Checked == true)
                    {
                        daGiac.CoToMau = true;
                    }

                    daGiac.Points.Add(e.Location);
                    daGiac.Points.Add(new Point());

                    DaGiac = true;

                    Hinh.Add(daGiac);
                }
                else
                {
                    DaGiac daGiac = (DaGiac)Hinh[Hinh.Count - 1];
                    daGiac.Points[daGiac.Points.Count - 1] = e.Location;
                    daGiac.Points.Add(new Point());
                }
            }

            //Vẽ đường cong
            if (currShapMode == shapeMode.DuongCongBezier)
            {
                if (this.DuongCong == false)
                {
                    Bezier bezier = new Bezier();
                    bezier.Pen = new Pen(btnMau.BackColor, (float)currPenSize);
                    bezier.dash = currDash;

                    bezier.points.Add(e.Location);
                    bezier.points.Add(new Point());

                    this.DuongCong = true;
                    Hinh.Add(bezier);
                }
                else
                {
                    Bezier bezier = (Bezier)Hinh[Hinh.Count - 1];
                    if (bezier.points.Count < 4)
                    {
                        bezier.points[bezier.points.Count - 1] = e.Location;
                        bezier.points.Add(new Point());
                    }
                    else
                    {
                        bezier.points.Add(e.Location);
                        DuongCong = false;
                        bezier.points.RemoveAt(bezier.points.Count - 1);
                        main.Refresh();
                    }
                }
            }
        }

        private void main_MouseMove(object sender, MouseEventArgs e)
        {
            this.isDown = true;
            
            if (this.DuongThang == true)
            {
               DuongThang duongThang = (DuongThang)Hinh[Hinh.Count - 1];
              duongThang.Points[duongThang.Points.Count - 1] = e.Location;

               main.Refresh();


            }
            if(this.HCN == true)
            {
                HCN hCN = (HCN)Hinh[Hinh.Count - 1];
                hCN.Points[hCN.Points.Count - 1] = e.Location;

                main.Refresh();
            }
            if(this.HV == true)
            {
                HV hV = (HV)Hinh[Hinh.Count - 1];
                hV.Points[hV.Points.Count - 1] = e.Location;

                main.Refresh();
            }
            if(this.HT == true)
            {
                HT hT = (HT)Hinh[Hinh.Count - 1];
                hT.Points[hT.Points.Count - 1] = e.Location;

                main.Refresh();
            }
            if(this.HELLIPSE == true)
            {
                Ellipse hEllipse = (Ellipse)Hinh[Hinh.Count - 1];
                hEllipse.Points[hEllipse.Points.Count - 1] = e.Location;
           
                main.Refresh();
            }
            if (this.DuongCong == true)
            {
               Bezier _bezier = (Bezier)Hinh[Hinh.Count - 1];
               _bezier.points[_bezier.points.Count - 1] = e.Location;

               main.Refresh();
            }
            if (this.DaGiac == true)
            {
                DaGiac DaGiac = (DaGiac)Hinh[Hinh.Count - 1];
                DaGiac.Points[DaGiac.Points.Count - 1] = e.Location;

                main.Refresh();
               
            }
           
        }

        private void main_MouseUp(object sender, MouseEventArgs e)
        {
            this.isDown = false;
        }

        private void btnDuongCong_Click(object sender, EventArgs e)
        {
            currShapMode = shapeMode.DuongCongBezier;
           
        }

        private void main_DoubleClick(object sender, EventArgs e)
        {
            if (currShapMode == shapeMode.HinhDaGiac)
            {
                if (DaGiac == true)
                {
                    DaGiac = false;
                    DaGiac hinh = (DaGiac)Hinh[Hinh.Count - 1];
                    hinh.Points.RemoveAt(hinh.Points.Count - 1);
                    main.Refresh();
                }
            }
        }

        private void btnDaGiac_Click(object sender, EventArgs e)
        {
            currShapMode = shapeMode.HinhDaGiac;
        }

        private void btnDoanThang_Click(object sender, EventArgs e)
        {
            currShapMode = shapeMode.DoanThang;
           
        }

        private void btnHCN_Click(object sender, EventArgs e)
        {
            currShapMode = shapeMode.HinhChuNhat;
        }

        private void btnHV_Click(object sender, EventArgs e)
        {
            currShapMode = shapeMode.HinhVuong;
        }

        private void btnHT_Click(object sender, EventArgs e)
        {
            currShapMode = shapeMode.HinhTron;
        }

        private void btnEllipse_Click(object sender, EventArgs e)
        {
            currShapMode = shapeMode.HinhEllipse;
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("Bạn muốn tạo mới file chứ?", "Cảnh báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            if (res == DialogResult.OK)
            {
                Hinh.Clear();
                bitmap = new Bitmap(main.Height, main.Width);
                main.BackgroundImage = bitmap;
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("Bạn chắc chắn muốn thoát?", "Cảnh báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            if (res == DialogResult.OK)
                Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (Hinh.Count != 0)
            {
                Hinh.RemoveAt(Hinh.Count - 1);
                this.main.Refresh();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
                Hinh.RemoveRange(0, Hinh.Count);
                this.main.Refresh();
           
        }

        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {
            string netVe = comboBox1.SelectedItem.ToString();
            if (netVe == "Custom") currDash = DashStyle.Custom;
            if (netVe == "Dash") currDash = DashStyle.Dash;
            if (netVe == "DashDot") currDash = DashStyle.DashDot;
            if (netVe == "DashDotDot") currDash = DashStyle.DashDotDot;
            if (netVe == "Dot") currDash = DashStyle.Dot;
            if (netVe == "Solid") currDash = DashStyle.Solid;
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
           
        }
    }
}
