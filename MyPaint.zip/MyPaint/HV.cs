﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPaint
{
    public class HV : clsHinh
    {
        public List<Point> Points = new List<Point>();
        internal DashStyle dash;

        public override void Draw(Graphics graphics)
        {
            if (CoToMau == true)
            {
                graphics.FillRectangle(Brush, Points[0].X, Points[0].Y,
                    Points[1].Y - Points[0].Y, Points[1].Y - Points[0].Y);
            }
            else
            {
                Pen.DashStyle = dash;
                graphics.DrawRectangle(Pen, Points[0].X, Points[0].Y,
                    Points[1].Y - Points[0].Y, Points[1].Y - Points[0].Y);
            }
        }

    }
}
