﻿namespace MyPaint
{
    partial class Paint
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Paint));
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnSelect = new System.Windows.Forms.Button();
            this.btnGroup = new System.Windows.Forms.Button();
            this.btnMau = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbSize = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnHT = new System.Windows.Forms.Button();
            this.btnDuongCong = new System.Windows.Forms.Button();
            this.btnDaGiac = new System.Windows.Forms.Button();
            this.btnEllipse = new System.Windows.Forms.Button();
            this.btnHV = new System.Windows.Forms.Button();
            this.btnHCN = new System.Windows.Forms.Button();
            this.btnDoanThang = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radiobtnVeKhung = new System.Windows.Forms.RadioButton();
            this.radioBtnToMau = new System.Windows.Forms.RadioButton();
            this.main = new System.Windows.Forms.Panel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.diChuyểnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Location = new System.Drawing.Point(12, 27);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1266, 74);
            this.panel1.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.groupBox2.Controls.Add(this.btnSelect);
            this.groupBox2.Controls.Add(this.btnGroup);
            this.groupBox2.Controls.Add(this.btnMau);
            this.groupBox2.Controls.Add(this.comboBox1);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.cmbSize);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.btnHT);
            this.groupBox2.Controls.Add(this.btnDuongCong);
            this.groupBox2.Controls.Add(this.btnDaGiac);
            this.groupBox2.Controls.Add(this.btnEllipse);
            this.groupBox2.Controls.Add(this.btnHV);
            this.groupBox2.Controls.Add(this.btnHCN);
            this.groupBox2.Controls.Add(this.btnDoanThang);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(108, 0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1012, 71);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            // 
            // btnSelect
            // 
            this.btnSelect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSelect.Location = new System.Drawing.Point(803, 7);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(131, 30);
            this.btnSelect.TabIndex = 16;
            this.btnSelect.Text = "Select";
            this.btnSelect.UseVisualStyleBackColor = true;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // btnGroup
            // 
            this.btnGroup.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGroup.Location = new System.Drawing.Point(803, 39);
            this.btnGroup.Name = "btnGroup";
            this.btnGroup.Size = new System.Drawing.Size(131, 29);
            this.btnGroup.TabIndex = 15;
            this.btnGroup.Text = "Group";
            this.btnGroup.UseVisualStyleBackColor = true;
            // 
            // btnMau
            // 
            this.btnMau.BackColor = System.Drawing.Color.Black;
            this.btnMau.BackgroundImage = global::MyPaint.Properties.Resources.MoreColor;
            this.btnMau.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnMau.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMau.Location = new System.Drawing.Point(664, 12);
            this.btnMau.Name = "btnMau";
            this.btnMau.Size = new System.Drawing.Size(93, 48);
            this.btnMau.TabIndex = 1;
            this.btnMau.UseVisualStyleBackColor = false;
            this.btnMau.Click += new System.EventHandler(this.btnMau_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Custom",
            "Dash",
            "DashDot",
            "DashDotDot",
            "Soild"});
            this.comboBox1.Location = new System.Drawing.Point(506, 39);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(94, 23);
            this.comboBox1.TabIndex = 12;
            this.comboBox1.SelectedValueChanged += new System.EventHandler(this.comboBox1_SelectedValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Location = new System.Drawing.Point(615, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Màu :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(446, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 15);
            this.label3.TabIndex = 11;
            this.label3.Text = "kiểu Vẽ";
            // 
            // cmbSize
            // 
            this.cmbSize.FormattingEnabled = true;
            this.cmbSize.Location = new System.Drawing.Point(506, 14);
            this.cmbSize.Name = "cmbSize";
            this.cmbSize.Size = new System.Drawing.Size(94, 23);
            this.cmbSize.TabIndex = 3;
            this.cmbSize.SelectedIndexChanged += new System.EventHandler(this.cmbSize_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(457, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "Size :";
            // 
            // btnHT
            // 
            this.btnHT.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnHT.BackgroundImage = global::MyPaint.Properties.Resources.Hinhtron;
            this.btnHT.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnHT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHT.Location = new System.Drawing.Point(187, 12);
            this.btnHT.Name = "btnHT";
            this.btnHT.Size = new System.Drawing.Size(55, 48);
            this.btnHT.TabIndex = 5;
            this.btnHT.UseVisualStyleBackColor = true;
            this.btnHT.Click += new System.EventHandler(this.btnHT_Click);
            // 
            // btnDuongCong
            // 
            this.btnDuongCong.BackgroundImage = global::MyPaint.Properties.Resources.Capture6;
            this.btnDuongCong.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDuongCong.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDuongCong.Location = new System.Drawing.Point(375, 12);
            this.btnDuongCong.Name = "btnDuongCong";
            this.btnDuongCong.Size = new System.Drawing.Size(58, 48);
            this.btnDuongCong.TabIndex = 8;
            this.btnDuongCong.UseVisualStyleBackColor = true;
            this.btnDuongCong.Click += new System.EventHandler(this.btnDuongCong_Click);
            // 
            // btnDaGiac
            // 
            this.btnDaGiac.BackgroundImage = global::MyPaint.Properties.Resources.LucGiac;
            this.btnDaGiac.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDaGiac.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDaGiac.Location = new System.Drawing.Point(311, 12);
            this.btnDaGiac.Name = "btnDaGiac";
            this.btnDaGiac.Size = new System.Drawing.Size(58, 48);
            this.btnDaGiac.TabIndex = 7;
            this.btnDaGiac.UseVisualStyleBackColor = true;
            this.btnDaGiac.Click += new System.EventHandler(this.btnDaGiac_Click);
            // 
            // btnEllipse
            // 
            this.btnEllipse.BackgroundImage = global::MyPaint.Properties.Resources.Ellipse1;
            this.btnEllipse.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnEllipse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEllipse.Location = new System.Drawing.Point(247, 12);
            this.btnEllipse.Name = "btnEllipse";
            this.btnEllipse.Size = new System.Drawing.Size(58, 48);
            this.btnEllipse.TabIndex = 6;
            this.btnEllipse.UseVisualStyleBackColor = true;
            this.btnEllipse.Click += new System.EventHandler(this.btnEllipse_Click);
            // 
            // btnHV
            // 
            this.btnHV.BackgroundImage = global::MyPaint.Properties.Resources.hinhvuong;
            this.btnHV.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnHV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHV.Location = new System.Drawing.Point(127, 12);
            this.btnHV.Name = "btnHV";
            this.btnHV.Size = new System.Drawing.Size(58, 48);
            this.btnHV.TabIndex = 4;
            this.btnHV.UseVisualStyleBackColor = true;
            this.btnHV.Click += new System.EventHandler(this.btnHV_Click);
            // 
            // btnHCN
            // 
            this.btnHCN.BackgroundImage = global::MyPaint.Properties.Resources.Rectangle;
            this.btnHCN.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnHCN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHCN.Location = new System.Drawing.Point(66, 12);
            this.btnHCN.Name = "btnHCN";
            this.btnHCN.Size = new System.Drawing.Size(58, 48);
            this.btnHCN.TabIndex = 3;
            this.btnHCN.UseVisualStyleBackColor = true;
            this.btnHCN.Click += new System.EventHandler(this.btnHCN_Click);
            // 
            // btnDoanThang
            // 
            this.btnDoanThang.BackgroundImage = global::MyPaint.Properties.Resources.Line;
            this.btnDoanThang.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDoanThang.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDoanThang.Location = new System.Drawing.Point(6, 12);
            this.btnDoanThang.Name = "btnDoanThang";
            this.btnDoanThang.Size = new System.Drawing.Size(58, 48);
            this.btnDoanThang.TabIndex = 2;
            this.btnDoanThang.UseVisualStyleBackColor = true;
            this.btnDoanThang.Click += new System.EventHandler(this.btnDoanThang_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button1);
            this.groupBox3.Controls.Add(this.button2);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(1120, 0);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(146, 74);
            this.groupBox3.TabIndex = 9;
            this.groupBox3.TabStop = false;
            // 
            // button1
            // 
            this.button1.BackgroundImage = global::MyPaint.Properties.Resources.download__2_;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(75, 14);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(59, 46);
            this.button1.TabIndex = 9;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackgroundImage = global::MyPaint.Properties.Resources.download__3_;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(6, 14);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(63, 46);
            this.button2.TabIndex = 10;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radiobtnVeKhung);
            this.groupBox1.Controls.Add(this.radioBtnToMau);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(3, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(104, 74);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Bút Vẽ";
            // 
            // radiobtnVeKhung
            // 
            this.radiobtnVeKhung.AutoSize = true;
            this.radiobtnVeKhung.Location = new System.Drawing.Point(6, 20);
            this.radiobtnVeKhung.Name = "radiobtnVeKhung";
            this.radiobtnVeKhung.Size = new System.Drawing.Size(86, 19);
            this.radiobtnVeKhung.TabIndex = 0;
            this.radiobtnVeKhung.TabStop = true;
            this.radiobtnVeKhung.Text = "Vẽ Khung";
            this.radiobtnVeKhung.UseVisualStyleBackColor = true;
            // 
            // radioBtnToMau
            // 
            this.radioBtnToMau.AutoSize = true;
            this.radioBtnToMau.Location = new System.Drawing.Point(6, 45);
            this.radioBtnToMau.Name = "radioBtnToMau";
            this.radioBtnToMau.Size = new System.Drawing.Size(73, 19);
            this.radioBtnToMau.TabIndex = 1;
            this.radioBtnToMau.TabStop = true;
            this.radioBtnToMau.Text = "Tô Màu";
            this.radioBtnToMau.UseVisualStyleBackColor = true;
            // 
            // main
            // 
            this.main.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.main.BackColor = System.Drawing.Color.White;
            this.main.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.main.Cursor = System.Windows.Forms.Cursors.Cross;
            this.main.Location = new System.Drawing.Point(12, 97);
            this.main.Name = "main";
            this.main.Size = new System.Drawing.Size(1263, 419);
            this.main.TabIndex = 1;
            this.main.Paint += new System.Windows.Forms.PaintEventHandler(this.main_Paint);
            this.main.DoubleClick += new System.EventHandler(this.main_DoubleClick);
            this.main.MouseDown += new System.Windows.Forms.MouseEventHandler(this.main_MouseDown);
            this.main.MouseMove += new System.Windows.Forms.MouseEventHandler(this.main_MouseMove);
            this.main.MouseUp += new System.Windows.Forms.MouseEventHandler(this.main_MouseUp);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1278, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.Size = new System.Drawing.Size(98, 22);
            this.newToolStripMenuItem.Text = "&New";
            this.newToolStripMenuItem.Click += new System.EventHandler(this.newToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(98, 22);
            this.exitToolStripMenuItem.Text = "&Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.diChuyểnToolStripMenuItem,
            this.groupToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.editToolStripMenuItem.Text = "&Edit";
            // 
            // diChuyểnToolStripMenuItem
            // 
            this.diChuyểnToolStripMenuItem.Name = "diChuyểnToolStripMenuItem";
            this.diChuyểnToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.diChuyểnToolStripMenuItem.Text = "&Di chuyển";
            // 
            // groupToolStripMenuItem
            // 
            this.groupToolStripMenuItem.Name = "groupToolStripMenuItem";
            this.groupToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.groupToolStripMenuItem.Text = "&Group";
            // 
            // Paint
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1278, 528);
            this.Controls.Add(this.main);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Paint";
            this.Text = "Paint Đơn Giản";
            this.panel1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel main;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnDoanThang;
        private System.Windows.Forms.RadioButton radioBtnToMau;
        private System.Windows.Forms.RadioButton radiobtnVeKhung;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnDuongCong;
        private System.Windows.Forms.Button btnDaGiac;
        private System.Windows.Forms.Button btnEllipse;
        private System.Windows.Forms.Button btnHT;
        private System.Windows.Forms.Button btnHV;
        private System.Windows.Forms.Button btnHCN;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnMau;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbSize;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem diChuyểnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem groupToolStripMenuItem;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnGroup;
        private System.Windows.Forms.Button btnSelect;
    }
}

