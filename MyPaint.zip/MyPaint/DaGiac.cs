﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPaint
{
    public class DaGiac : clsHinh
    {
        public List<Point> Points = new List<Point>();
        internal DashStyle dash;

        public override void Draw(Graphics graphics)
        {
            if (CoToMau == true)
            {
              
                if (Points.Count == 2)
                {
                    graphics.DrawLine(Pen, Points[0], Points[1]);
                }
                else
                {
                    graphics.FillPolygon(Brush, Points.ToArray());
                }
            }
            else
            {
                Pen.DashStyle = dash;
                graphics.DrawPolygon(Pen, Points.ToArray());
            }
        }
    }
}

